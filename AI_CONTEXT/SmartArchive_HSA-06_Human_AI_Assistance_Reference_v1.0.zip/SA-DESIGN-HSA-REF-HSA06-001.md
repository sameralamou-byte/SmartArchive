# SmartArchive HSA-06 — Human + AI Assistance
## Visual Concept Analysis & Reference Record

**Document ID:** SA-DESIGN-HSA-REF-HSA06-001  
**Concept ID:** HSA-06  
**Version:** v1.0  
**Date:** 15 August 2026  
**Status:** Visual concept / reference candidate — NOT a production design freeze  
**Scope:** HSA visual direction evaluation and reference documentation  
**Authority:** Founder review required before promotion to official design authority

---

## 1. Purpose

This document records the visual concept developed for SmartArchive Home (HSA): a real human interacting with a subtle, transparent AI hand emerging from a computer.

The concept is intended to communicate:

> **Human in control. AI here to help.**

It is a visual direction candidate, not an implementation specification.

The image may be used to communicate the intended emotional and visual direction to the SmartArchive AI/reviewer group. It must not be treated as permission to copy the generated UI, text, numbers, icons, or feature claims into the product.

---

## 2. Core Concept

### Human–AI relationship

The human hand is the primary physical and emotional subject. A semi-transparent AI hand emerges from the computer and reaches toward the human.

The visual relationship is deliberately cooperative rather than dominant:

**Human → chooses / decides**  
**AI → understands / explains / assists**

The contact point between the two hands represents a connection or "thread" of assistance.

### Intended message

- AI is present but not frightening.
- AI is helpful but not autonomous.
- Technology remains inside the user's everyday environment.
- The human remains the decision-maker.
- SmartArchive reduces document stress by turning information into understandable next steps.

---

## 3. Emotional / Sentiment Analysis

### Primary sentiment

**Trust + relief + human warmth**

### Secondary sentiments

- Calm
- Safety
- Support
- Clarity
- Connection
- Empowerment
- Familiarity
- Confidence
- Family protection
- Future readiness without science-fiction distance

### Emotional balance

| Dimension | Intended level |
|---|---:|
| Warmth | 90% |
| Human presence | 95% |
| Calmness | 85% |
| Trust | 90% |
| Technology visibility | 55% |
| AI visibility | 50% |
| Futuristic feeling | 25% |
| Sci-fi feeling | 10% |
| Enterprise/technical density | 35% |
| Family/home feeling | 90% |

These percentages are **visual-direction estimates**, not measured UX research.

### Emotional principle

The technology should support the human scene rather than become the scene.

---

## 4. Human Presence

The real human hand is intentionally stronger than the AI hand.

### Required relationship

- Human hand: natural skin texture, physically grounded, visually dominant.
- AI hand: transparent, luminous, lightweight, visually secondary.
- Contact point: subtle light/thread connection.
- No robot body.
- No mechanical arm.
- No humanoid robot.
- No autonomous-machine impression.

### Why this matters

This supports the SmartArchive principle:

> **AI suggests; the human decides.**

The visual should never imply that SmartArchive takes control of the user's life.

---

## 5. AI Representation

The AI is represented as a **transparent digital hand**, not as a robot, head, chatbot mascot, or physical appliance.

### Recommended visual characteristics

- Approximate transparency/opacity: **35–50%**
- Soft luminous edge
- Fine particle/thread structure
- Restrained glow
- No hard holographic box
- No neon sci-fi aura
- No artificial face
- No robot mechanics

The AI hand should remain visually subordinate to the human hand.

### Interpretation

The AI hand represents:

- Understanding
- Assistance
- Guidance
- Translation
- Explanation
- Connecting information to action

It does **not** represent:

- Human replacement
- Autonomous control
- Physical hardware
- Surveillance
- A SmartArchive robot product

---

## 6. Color Direction

The image uses a warm domestic photographic environment combined with a dark petrol/teal interface and restrained copper accents.

### Approximate visual palette

| Role | Approximate color | Character |
|---|---|---|
| Deep grounding | `#04151A` | Petrol/deep teal |
| Dark interface | `#101C1E` | Soft charcoal-teal |
| Secondary teal | `#041C20` | Deep blue-green |
| Warm wood | `#3A2610` | Natural warm brown |
| Copper accent | `#BD7A4F` / similar | Rose-copper direction |
| Thread/light accent | warm gold/white | Controlled emphasis |
| Paper | warm off-white | Human/document warmth |
| Textile | muted beige/olive | Domestic calm |

These values are **visual approximations extracted from the concept image**, not approved production tokens.

### Color balance

- Dark/petrol UI grounding: approximately 35–45%
- Warm wood / home environment: approximately 25–35%
- Neutral paper/textile surfaces: approximately 15–25%
- Copper/gold accents: approximately 5–10%
- AI luminous treatment: small focal percentage only

The goal is **warm home + controlled Weave technology**, not neon technology.

---

## 7. Lighting

### Main lighting

Warm natural daylight enters through the background window.

### Secondary lighting

Warm indoor lamps provide domestic depth.

### Digital lighting

The AI hand and UI use a restrained cool/neutral luminous edge to separate digital assistance from the physical environment.

### Lighting principle

The physical home remains visually warmer and more inviting than the digital layer.

The digital layer should feel integrated into life rather than replacing it.

### Approximate lighting character

- Warm ambient home light: dominant
- Natural daylight: medium/high
- Digital glow: low/medium
- High-contrast neon: prohibited
- Extreme sci-fi illumination: prohibited

---

## 8. Materials & Physical Texture

The concept intentionally combines familiar household materials with digital surfaces.

### Physical materials

**Wood**
- Warm natural wood desk
- Supports familiarity and domestic stability

**Paper**
- Realistic document sheets and notebook
- Reinforces document-first identity

**Textiles**
- Clothing, upholstery and soft household surfaces
- Creates emotional comfort

**Ceramic**
- Coffee mug and household objects
- Adds everyday-life realism

**Glass**
- Window surfaces
- Provides natural light and openness

**Metal**
- Laptop hardware and small office details
- Keeps the scene contemporary without making it industrial

### Digital materials

**Matte/dark interface**
- Low-reflection petrol/teal panels
- Designed to avoid aggressive futuristic HUD styling

**Digital thread**
- Fine luminous connection
- Represents understanding and continuity

**AI hand**
- Transparent/light digital material
- Should feel like a visual representation of assistance, not physical hardware

---

## 9. Composition

### Primary focal hierarchy

1. Human hand
2. Human–AI connection point
3. Computer / SmartArchive interface
4. Family/home context
5. File Locker / documents
6. Timeline/reminders
7. Supporting brand information

The human should remain the emotional anchor.

### Spatial principle

The computer is the bridge between the person's real document life and SmartArchive's intelligence.

The AI should visually emerge **from the computer**, reinforcing:

> SmartArchive intelligence is part of the user's document environment.

---

## 10. File Locker Representation

The visible File Locker is useful as a **conceptual visual metaphor** for document organization.

It communicates:

- Documents are stored
- Documents are categorized
- Documents remain accessible
- Personal and family information can be organized
- SmartArchive is more than a chatbot

### Important restriction

The exact folder counts, labels, numbers, and visual chrome shown in the generated image are **illustrative only**.

They are not approved product data or UI requirements.

---

## 11. SmartArchive Thread

The bottom storyline visually represents:

**Document → Understand → Confidence → Source → Action → Reminder → Timeline**

This is strongly aligned with the current SmartArchive product narrative.

### Visual interpretation

The thread connects separate capabilities without making the user feel that they are navigating unrelated tools.

The thread should remain:

- simple
- calm
- understandable
- human-readable
- consistent with Weave

---

## 12. Home / Family Context

The background family scene is intentionally soft and secondary.

Its role is to communicate:

- SmartArchive belongs in real life.
- Documents affect people and families.
- The product is not only an enterprise system.
- Technology should reduce cognitive burden rather than increase it.

The family should remain natural and non-staged.

---

## 13. Typography Direction

The concept image contains generated text for demonstration.

For production, typography must follow the approved Weave typography system already present in the repository.

**Do not copy generated typography directly from this image.**

Production language remains subject to:

- Weave tokens
- Cairo
- IBM Plex Sans
- Cascadia Code where appropriate
- EN / DE / AR
- RTL support
- WCAG 2.1 AA

---

## 14. What Should Be Retained

### Strong principles

- Real human
- Real home
- Real document environment
- Human hand as primary actor
- Transparent AI assistance
- Warm domestic lighting
- Petrol/deep grounding
- Restrained copper/gold accents
- File organization metaphor
- Document-to-action thread
- Family context
- Human control
- Calm technology

---

## 15. What Must NOT Be Copied

The following are **not approved requirements** merely because they appear in the generated image:

- Exact UI layout
- Exact navigation
- Exact wording
- Exact document names
- Exact numbers
- Exact confidence percentages
- Specific customer/company names
- Specific dates
- Specific feature buttons
- Generated icons
- Generated logos
- Pricing
- Hardware
- Physical file-locker product
- Any generated feature not already approved by SmartArchive governance

The image is a **visual direction reference**, not a product specification.

---

## 16. HSA Governance Classification

**Candidate:** HSA-06 Human + AI Assistance

**Current status:** CONTINUE TO REVIEW

**Recommended role:** Human–AI emotional/visual direction candidate

**Not yet:** Design freeze

**Not yet:** Production implementation authority

**Not yet:** UI specification

### Proposed review path

1. Founder / project owner review
2. Claude independent review
3. Cursor independent review
4. Reviewer 3 independent review
5. Reviewer 4 independent review
6. Consolidated score
7. Founder decision
8. If required threshold is achieved → HSA design-freeze process

---

## 17. Review Questions for the AI Group

Each reviewer should answer independently:

1. Does the human–AI hand relationship communicate **AI assistance without replacing the human**?
2. Is the AI hand sufficiently transparent and visually subordinate?
3. Does the warm home context fit HSA?
4. Does the color direction fit Weave?
5. Does the concept avoid sci-fi/robotic/holographic excess?
6. Does the File Locker metaphor support SmartArchive's document-first identity?
7. Does the SmartArchive Thread communicate the product's core loop?
8. Does the scene build trust and emotional comfort?
9. What should be retained?
10. What should be changed or removed?
11. Score from 0–10.
12. YES / NO for continuing to final review.

Reviewers must evaluate the concept independently and must not use another reviewer's score as a basis.

---

## 18. Final Concept Statement

The strongest idea in HSA-06 is not the computer and not the AI hand.

It is the **relationship between them**:

> **A real person reaches toward SmartArchive, and SmartArchive reaches back to help — while the person remains in control.**

That is the intended emotional center of this concept.

---

## 19. Authority Note

This document does not override:

- Founder decisions
- Master Project Context
- Locked ADRs
- Approved Weave tokens/components
- Future design-freeze decisions

It is a controlled **visual analysis/reference record only**.

**Status:** Awaiting independent AI-group review and Founder decision.
